#ifndef PARCOURS_H
#define PARCOURS_H

#include "noeud.h"

void parcours_largeur(Noeud* racine);

#endif